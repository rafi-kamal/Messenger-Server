package messenger.server.controller.filetransfer;

public class DownloadInfo
{
	int filesRecieving;
	long filesSize;
	long bytesRecieved;
}
